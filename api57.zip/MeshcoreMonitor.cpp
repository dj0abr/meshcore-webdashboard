#include "MeshcoreMonitor.h"

#include "MeshCoreProto.h"

#include <algorithm>
#include <chrono>
#include <cctype>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>

namespace
{
    std::mutex g_monitorMutex;

    std::string CodeToHex(uint8_t code)
    {
        std::ostringstream oss;

        oss << "0x"
            << std::hex
            << std::uppercase
            << std::setw(2)
            << std::setfill('0')
            << static_cast<unsigned>(code);

        return oss.str();
    }

    std::string ShortHex(const std::vector<uint8_t> &data, size_t maxChars)
    {
        std::string hex = MeshRxLogDecoder::BytesToHex(data);

        if (hex.size() <= maxChars)
        {
            return hex;
        }

        return hex.substr(0, maxChars) + "...";
    }

    std::string PushCodeToString(uint8_t code)
    {
        switch (code)
        {
            case MeshCoreProto::PUSH_CODE_ADVERT:
                return "ADVERT";

            case MeshCoreProto::PUSH_CODE_PATH_UPDATED:
                return "PATH_UPDATED";

            case MeshCoreProto::PUSH_CODE_SEND_CONFIRMED:
                return "SEND_CONFIRMED";

            case MeshCoreProto::PUSH_CODE_MSG_WAITING:
                return "MSG_WAITING";

            case MeshCoreProto::PUSH_CODE_RAW_DATA:
                return "RAW_DATA";

            case MeshCoreProto::PUSH_CODE_LOGIN_SUCCESS:
                return "LOGIN_SUCCESS";

            case MeshCoreProto::PUSH_CODE_LOGIN_FAIL:
                return "LOGIN_FAIL";

            case MeshCoreProto::PUSH_CODE_STATUS_RESPONSE:
                return "STATUS_RESPONSE";

            case MeshCoreProto::PUSH_CODE_RX_LOG_DATA:
                return "RX_LOG_DATA";

            case MeshCoreProto::PUSH_CODE_TRACE_DATA:
                return "TRACE_DATA";

            case MeshCoreProto::PUSH_CODE_NEW_ADVERT:
                return "NEW_ADVERT";

            case MeshCoreProto::PUSH_CODE_TELEMETRY_RESPONSE:
                return "TELEMETRY_RESPONSE";

            case MeshCoreProto::PUSH_CODE_BINARY_RESPONSE:
                return "BINARY_RESPONSE";

            case MeshCoreProto::PUSH_CODE_CONTROL_DATA:
                return "CONTROL_DATA";

            default:
                return "UNKNOWN";
        }
    }

    std::string BytesToPrintableText(const std::vector<uint8_t> &data)
    {
        std::string out;
        out.reserve(data.size());

        for (uint8_t b : data)
        {
            if (b == '\r' || b == '\n' || b == '\t')
            {
                out.push_back(static_cast<char>(b));
            }
            else if (std::isprint(static_cast<unsigned char>(b)) != 0)
            {
                out.push_back(static_cast<char>(b));
            }
            else
            {
                out.push_back('.');
            }
        }

        return out;
    }

    bool LooksPrintableEnough(const std::vector<uint8_t> &data)
    {
        if (data.empty())
        {
            return false;
        }

        size_t printable = 0;

        for (uint8_t b : data)
        {
            if (b == '\r' || b == '\n' || b == '\t' || std::isprint(static_cast<unsigned char>(b)) != 0)
            {
                ++printable;
            }
        }

        return ((printable * 100U) / data.size()) >= 80U;
    }

    void PrintPktHash(uint32_t pktHash)
    {
        std::cout << "  pktHash       : 0x"
                  << std::hex
                  << std::uppercase
                  << std::setw(8)
                  << std::setfill('0')
                  << pktHash
                  << std::dec
                  << std::nouppercase
                  << std::setfill(' ')
                  << std::endl;
    }
}

void MeshcoreMonitor(
    const std::string &source,
    uint8_t code,
    const std::vector<uint8_t> &payload,
    const MeshRxLogDecoder::DecodedPacket *pkt
)
{
    std::lock_guard<std::mutex> lock(g_monitorMutex);

    const auto now = std::chrono::system_clock::now();
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        now.time_since_epoch()
    ).count();

    if (pkt != nullptr)
    {
        std::cout << "[MESHCORE MONITOR " << ms << "] "
                  << source
                  << " routeType=" << static_cast<int>(pkt->routeType)
                  << " payloadType=" << MeshRxLogDecoder::PayloadTypeToString(pkt->payloadType)
                  << " payloadVersion=" << static_cast<int>(pkt->payloadVersion)
                  << " snr=" << pkt->snrDb
                  << " rssi=" << static_cast<int>(pkt->rssiDbm)
                  << " pathLen=" << static_cast<int>(pkt->pathLen)
                  << " path=" << MeshRxLogDecoder::FormatPath(*pkt)
                  << " pktHash=0x"
                  << std::hex
                  << std::uppercase
                  << std::setw(8)
                  << std::setfill('0')
                  << pkt->pktHash
                  << std::dec
                  << std::nouppercase
                  << std::setfill(' ');

        if (pkt->payloadType == MeshCoreProto::PAYLOAD_TYPE_ADVERT && pkt->advertValid)
        {
            std::cout << " advert";

            if (!pkt->advertName.empty())
            {
                std::cout << " name=" << pkt->advertName;
            }

            std::cout << " role=" << static_cast<int>(pkt->advertRole);

            if (!pkt->advertPublicKey.empty())
            {
                std::cout << " pk=" << ShortHex(pkt->advertPublicKey, 24);
            }
        }
        else if (pkt->payloadType == MeshCoreProto::PAYLOAD_TYPE_GRP_TXT && pkt->grpTxtValid)
        {
            std::cout << " grp"
                      << " channel=" << CodeToHex(pkt->grpChannelHash)
                      << " decryptOk=" << (pkt->grpDecryptOk ? "yes" : "no");

            if (pkt->grpDecryptOk && !pkt->grpText.empty())
            {
                std::cout << " text=\"" << pkt->grpText << "\"";
            }
        }

        if (!pkt->valid)
        {
            std::cout << " INVALID";
        }

        std::cout << std::endl;
    }
    else
    {
        std::cout << "[MESHCORE MONITOR " << ms << "] "
                  << source
                  << " code=" << CodeToHex(code)
                  << " (" << PushCodeToString(code) << ")"
                  << " payloadLen=" << payload.size()
                  << std::endl;
    }

    if (pkt == nullptr)
    {
        std::cout << "  raw           : " << MeshRxLogDecoder::BytesToHex(payload) << std::endl;

        if (LooksPrintableEnough(payload))
        {
            std::cout << "  ascii         : " << BytesToPrintableText(payload) << std::endl;
        }

        std::cout << std::endl;
        return;
    }

    std::cout << "  valid         : " << (pkt->valid ? "yes" : "no") << std::endl;

    if (!pkt->decodeError.empty())
    {
        std::cout << "  decodeError   : " << pkt->decodeError << std::endl;
    }

    std::cout << "  snr           : " << pkt->snrDb << " dB" << std::endl;
    std::cout << "  rssi          : " << static_cast<int>(pkt->rssiDbm) << " dBm" << std::endl;
    std::cout << "  routeType     : " << static_cast<int>(pkt->routeType)
              << " (" << MeshRxLogDecoder::RouteTypeToString(pkt->routeType) << ")"
              << std::endl;
    std::cout << "  payloadType   : " << static_cast<int>(pkt->payloadType)
              << " (" << MeshRxLogDecoder::PayloadTypeToString(pkt->payloadType) << ")"
              << std::endl;
    std::cout << "  payloadVer    : " << static_cast<int>(pkt->payloadVersion) << std::endl;
    std::cout << "  pathLen       : " << static_cast<int>(pkt->pathLen) << std::endl;
    std::cout << "  pathHashSize  : " << static_cast<int>(pkt->pathHashSize) << std::endl;
    std::cout << "  path          : " << MeshRxLogDecoder::FormatPath(*pkt) << std::endl;
    PrintPktHash(pkt->pktHash);

    std::cout << "  rfPacket      : " << MeshRxLogDecoder::BytesToHex(pkt->rfPacket) << std::endl;
    std::cout << "  pktPayloadLen : " << pkt->pktPayload.size() << std::endl;
    std::cout << "  pktPayload    : " << MeshRxLogDecoder::BytesToHex(pkt->pktPayload) << std::endl;

    if (LooksPrintableEnough(pkt->pktPayload))
    {
        std::cout << "  pktAscii      : " << BytesToPrintableText(pkt->pktPayload) << std::endl;
    }

    if (pkt->payloadType == MeshCoreProto::PAYLOAD_TYPE_REQ && pkt->reqValid)
    {
        std::cout << "  req.dstHash   : " << CodeToHex(pkt->reqDstHash) << std::endl;
        std::cout << "  req.srcHash   : " << CodeToHex(pkt->reqSrcHash) << std::endl;
        std::cout << "  req.mac       : 0x"
                  << std::hex
                  << std::uppercase
                  << std::setw(4)
                  << std::setfill('0')
                  << pkt->reqMac
                  << std::dec
                  << std::nouppercase
                  << std::setfill(' ')
                  << std::endl;
        std::cout << "  req.cipherLen : " << pkt->reqCipherText.size() << std::endl;
    }

    if (pkt->payloadType == MeshCoreProto::PAYLOAD_TYPE_GRP_TXT && pkt->grpTxtValid)
    {
        std::cout << "  grp.channel   : " << CodeToHex(pkt->grpChannelHash) << std::endl;
        std::cout << "  grp.mac       : 0x"
                  << std::hex
                  << std::uppercase
                  << std::setw(4)
                  << std::setfill('0')
                  << pkt->grpMac
                  << std::dec
                  << std::nouppercase
                  << std::setfill(' ')
                  << std::endl;
        std::cout << "  grp.decryptOk : " << (pkt->grpDecryptOk ? "yes" : "no") << std::endl;

        if (pkt->grpDecryptOk)
        {
            std::cout << "  grp.text      : " << pkt->grpText << std::endl;
        }
    }

    if (pkt->payloadType == MeshCoreProto::PAYLOAD_TYPE_ADVERT && pkt->advertValid)
    {
        std::cout << "  adv.publicKey : " << MeshRxLogDecoder::BytesToHex(pkt->advertPublicKey) << std::endl;
        std::cout << "  adv.timestamp : " << pkt->advertTimestamp << std::endl;
        std::cout << "  adv.role      : " << static_cast<int>(pkt->advertRole)
                  << " (" << MeshRxLogDecoder::AdvertRoleToString(pkt->advertRole) << ")"
                  << std::endl;

        if (pkt->advertLocationValid)
        {
            std::cout << "  adv.latE6     : " << pkt->advertLatitudeE6 << std::endl;
            std::cout << "  adv.lonE6     : " << pkt->advertLongitudeE6 << std::endl;
        }

        if (!pkt->advertName.empty())
        {
            std::cout << "  adv.name      : " << pkt->advertName << std::endl;
        }
    }

    std::cout << std::endl;
}
