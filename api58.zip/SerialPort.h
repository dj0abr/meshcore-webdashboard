#pragma once

#include "IByteStream.h"

#include <cstddef>
#include <cstdint>
#include <string>

class SerialPort : public IByteStream
{
public:
    SerialPort();
    ~SerialPort() override;

    bool open(const std::string &device, int baud = 115200);

    void close() override;
    bool isOpen() const override;
    int fd() const;

    bool writeAll(const uint8_t *data, size_t len) override;
    bool readExact(uint8_t *data, size_t len, int timeoutMs) override;
    bool readByte(uint8_t &byte, int timeoutMs) override;

private:
    int m_fd;

    bool configure(int baud);
};